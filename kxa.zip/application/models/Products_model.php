<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Products_model extends CI_Model
{

    public function getAllProduct()
    {
        return $this->db->get('products')->result_array();
    }

    public function getAllCategories()
    {
        return $this->db->get('categories')->result_array();
    }

    public function getProductById($id)
    {
        return $this->db->get_where('products', ['id' => $id])->row_array();
    }

    public function getPhotoByPhoto($photo)
    {
        return $this->db->get_where('photo', ['photo' => $photo])->row_array();
    }

    public function getCategoryById($id)
    {
        return $this->db->get_where('categories', ['id' => $id])->row_array();
    }

    public function insertProduct()
    {
        $data = array();

        $photoloc = $_FILES['photo']['tmp_name'];
        $photo   = $_FILES['photo']['name'];
        $photo_new = date('dmYHis') . $photo;
        $directory   = './assets/img/categories/' . $photo_new;

        $photoloc1 = $_FILES['photo1']['tmp_name'];
        $photo1   = $_FILES['photo1']['name'];
        $photo1_new = date('dmYHis') . $photo1;
        $directory1   = './assets/img/categories/' . $photo1_new;

        $photoloc2 = $_FILES['photo2']['tmp_name'];
        $photo2   = $_FILES['photo2']['name'];
        $photo2_new = date('dmYHis') . $photo2;
        $directory2   = './assets/img/categories/' . $photo2_new;

        $photoloc3 = $_FILES['photo3']['tmp_name'];
        $photo3   = $_FILES['photo3']['name'];
        $photo3_new = date('dmYHis') . $photo3;
        $directory3   = './assets/img/categories/' . $photo3_new;

        $photoloc4 = $_FILES['photo4']['tmp_name'];
        $photo4   = $_FILES['photo4']['name'];
        $photo4_new = date('dmYHis') . $photo4;
        $directory4   = './assets/img/categories/' . $photo4_new;

        $photoloc5 = $_FILES['photo5']['tmp_name'];
        $photo5   = $_FILES['photo5']['name'];
        $photo5_new = date('dmYHis') . $photo5;
        $directory5   = './assets/img/categories/' . $photo5_new;

        if (!empty($photoloc)) {
            move_uploaded_file($photoloc, $directory);
            $data['photo'] = $photo_new;
        } else {
            $data['photo'] = '';
        }
        if (!empty($photoloc1)) {
            move_uploaded_file($photoloc1, $directory1);
            $data['photo1'] = $photo1_new;
        } else {
            $data['photo1'] = '';
        }
        if (!empty($photoloc2)) {
            move_uploaded_file($photoloc2, $directory2);
            $data['photo2'] = $photo2_new;
        } else {
            $data['photo2'] = '';
        }
        if (!empty($photoloc3)) {
            move_uploaded_file($photoloc3, $directory3);
            $data['photo3'] = $photo3_new;
        } else {
            $data['photo3'] = '';
        }
        if (!empty($photoloc4)) {
            move_uploaded_file($photoloc4, $directory4);
            $data['photo4'] = $photo4_new;
        } else {
            $data['photo4'] = '';
        }
        if (!empty($photoloc5)) {
            move_uploaded_file($photoloc5, $directory5);
            $data['photo5'] = $photo5_new;
        } else {
            $data['photo5'] = '';
        }

        $this->db->insert('photo', $data);

        $name = $this->input->post('name');
        $category = $this->input->post('category');
        $unit_price = $this->input->post('unit_price');
        $bukalapak = $this->input->post('bukalapak');
        $tokopedia = $this->input->post('tokopedia');
        $olx = $this->input->post('olx');
        $description = $this->input->post('description');


        $this->db->insert('products', [
            'name' => $name,
            'category_id' => $category,
            'photo' => $photo_new,
            'unit_price' => $unit_price,
            'bukalapak' => $bukalapak,
            'tokopedia' => $tokopedia,
            'olx' => $olx,
            'description' => $description,
            'date_created' => time()
        ]);
    }

    public function updateProduct($id)
    {
        $name = $this->input->post('name');
        $category = $this->input->post('category');
        $unit_price = $this->input->post('unit_price');
        $bukalapak = $this->input->post('bukalapak');
        $tokopedia = $this->input->post('tokopedia');
        $olx = $this->input->post('olx');
        $description = $this->input->post('description');

        $this->db->set('name', $name);
        $this->db->set('category_id', $category);
        $this->db->set('unit_price', $unit_price);
        $this->db->set('bukalapak', $bukalapak);
        $this->db->set('tokopedia', $tokopedia);
        $this->db->set('description', $description);
        $this->db->set('olx', $olx);
        $this->db->where('id', $id);
        $this->db->update('products');
    }

    public function deleteProduct($id, $photo)
    {
        $this->db->delete('products', ['id' => $id]);
        $this->db->delete('photo', ['photo' => $photo]);
    }

    public function deletePhoto1($photo)
    {
        $this->db->set('photo1', '');
        $this->db->where('photo', $photo);
        $this->db->update('photo');
    }

    public function deletePhoto2($photo)
    {
        $this->db->set('photo2', '');
        $this->db->where('photo', $photo);
        $this->db->update('photo');
    }

    public function deletePhoto3($photo)
    {
        $this->db->set('photo3', '');
        $this->db->where('photo', $photo);
        $this->db->update('photo');
    }

    public function deletePhoto4($photo)
    {
        $this->db->set('photo4', '');
        $this->db->where('photo', $photo);
        $this->db->update('photo');
    }

    public function deletePhoto5($photo)
    {
        $this->db->set('photo5', '');
        $this->db->where('photo', $photo);
        $this->db->update('photo');
    }

    public function updatePhoto($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo']['tmp_name'];
        $name_file   = $_FILES['photo']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function updatePhoto1($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo1']['tmp_name'];
        $name_file   = $_FILES['photo1']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo1'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo1'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo1', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo1', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function updatePhoto2($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo2']['tmp_name'];
        $name_file   = $_FILES['photo2']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo2'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo2'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo2', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo2', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function updatePhoto3($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo3']['tmp_name'];
        $name_file   = $_FILES['photo3']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo3'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo3'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo3', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo3', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function updatePhoto4($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo4']['tmp_name'];
        $name_file   = $_FILES['photo4']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo4'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo4'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo4', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo4', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function updatePhoto5($photo)
    {
        $data['photo'] = $this->db->get_where('photo', ['photo' => $photo])->row_array();

        $loc_file = $_FILES['photo5']['tmp_name'];
        $name_file   = $_FILES['photo5']['name'];
        $photo_new = date('dmYHis') . $name_file;
        $directory_file   = './assets/img/categories/' . $photo_new;

        if (file_exists('./assets/img/categories/' . $data['photo']['photo5'])) {
            if (unlink('./assets/img/categories/' . $data['photo']['photo5'])) {
                if (move_uploaded_file($loc_file, $directory_file)) {
                    $this->db->set('photo5', $photo_new);
                    $this->db->where('photo', $photo);
                    $this->db->update('photo');
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            if (move_uploaded_file($loc_file, $directory_file)) {
                $this->db->set('photo5', $photo_new);
                $this->db->where('photo', $photo);
                $this->db->update('photo');
            } else {
                return null;
            }
        }
    }

    public function getProduct($limit, $start, $keyword = null)
    {
        if ($keyword) {
            $this->db->like('name', $keyword);
            // $this->db->or_like('email', $keyword);
        }
        return $this->db->get('products', $limit, $start)->result_array();
    }

    public function countAllPeoples()
    {
        return $this->db->get('peoples')->num_rows();
    }

    public function category($category_id)
    {
        $query = "SELECT pr.id as id , pr.name as name , pr.photo as photo , pr.unit_price as unit_price
                    FROM products pr JOIN categories ca
                    ON pr.category_id=ca.id
                    WHERE pr.category_id =  $category_id";
        return $this->db->query($query)->result_array();
    }
}
